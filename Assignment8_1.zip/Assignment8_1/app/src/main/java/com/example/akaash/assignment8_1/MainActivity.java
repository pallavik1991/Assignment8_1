package com.example.akaash.assignment8_1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ListViewCompat;
import android.view.View;
import android.widget.*;

import java.util.Arrays;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    private Button btn_asc,btn_desc;
    private ListView list;

    String[] month={"Jan","Feb","Mar","Apr","May","Jun","July","Aug","Sep","Oct","Nov","Dec"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_asc=(Button)findViewById(R.id.button2);
        btn_desc=(Button)findViewById(R.id.button);
        list=(ListView)findViewById(R.id.list);


setList();


        btn_asc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Arrays.sort(month);
                setList();

            }
        });

        btn_desc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Arrays.sort(month, Collections.<String>reverseOrder());
                setList();
            }
        });
    }

    protected void setList()
    {
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(getBaseContext(),android.R.layout.simple_list_item_1,month);
        list.setAdapter(adapter);

    }
}
